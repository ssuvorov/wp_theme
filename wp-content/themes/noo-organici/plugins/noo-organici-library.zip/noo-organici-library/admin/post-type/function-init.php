<?php
$dir_pt = dirname( __FILE__ );
require_once $dir_pt.'/noo-boxed.php';
require_once $dir_pt.'/no-our-farmer.php';
require_once $dir_pt.'/noo-testimonials.php';